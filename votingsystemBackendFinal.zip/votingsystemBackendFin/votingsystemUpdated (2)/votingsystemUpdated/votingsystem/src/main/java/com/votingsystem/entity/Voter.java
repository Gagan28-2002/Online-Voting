package com.votingsystem.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;

@Entity
@Table(name = "voters")
public class Voter {

    @Id
    @GeneratedValue(generator="voter_seq")
    @SequenceGenerator(
            name = "voter_seq",
            sequenceName = "voter_SEQ",
            allocationSize = 1,
            initialValue = 3000      // voter IDs start from 3000
    )
    @Column(name = "voter_id")
    private int id;

    @Column(length = 30, name = "voter_name", nullable = false)
    private String name;

    @Column(length = 50, name = "voter_email", unique = true, nullable = false)
    private String email;

    @Column(length = 60, name = "voter_password", nullable = false)
    private String password;

    @Column(length = 10, name = "voter_phone", nullable = false)
    private String phone;

    @OneToMany(mappedBy = "voter")
    @JsonIgnore
    private List<Vote> votes;

    // ------------------ GETTERS & SETTERS ------------------

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public List<Vote> getVotes() {
        return votes;
    }

    public void setVotes(List<Vote> votes) {
        this.votes = votes;
    }
}
