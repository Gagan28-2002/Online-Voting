package com.votingsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.votingsystem.entity.Vote;

public interface VoteRepository extends JpaRepository<Vote, Integer> {

    long countByCandidateCandId(Integer candId);
    int countByElectionId(Integer electionId);
}
