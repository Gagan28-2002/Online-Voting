package com.votingsystem.service;

import org.springframework.stereotype.Service;

import com.votingsystem.entity.*;
import com.votingsystem.repository.*;
import com.votingsystem.exception.*;

@Service
public class VoteService {

    private final VoteRepository voteRepo;
    private final VoterRepository voterRepo;
    private final CandidateRepository candidateRepo;
    private final ElectionRepository electionRepo;

    public VoteService(
            VoteRepository voteRepo,
            VoterRepository voterRepo,
            CandidateRepository candidateRepo,
            ElectionRepository electionRepo
    ) {
        this.voteRepo = voteRepo;
        this.voterRepo = voterRepo;
        this.candidateRepo = candidateRepo;
        this.electionRepo = electionRepo;
    }

    public void castVote(Integer voterId, Integer candidateId, Integer electionId) {

        Voter voter = voterRepo.findById(voterId)
                .orElseThrow(() -> new ResourceNotFoundException("Voter not found"));

        Candidate candidate = candidateRepo.findById(candidateId)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found"));

        Election election = electionRepo.findById(electionId)
                .orElseThrow(() -> new ResourceNotFoundException("Election not found"));

        Vote v = new Vote();
        v.setVoter(voter);
        v.setCandidate(candidate);
        v.setElection(election);

        voteRepo.save(v);
    }
    public long getVotesForCandidate(Integer candidateId) {
        return voteRepo.countByCandidateCandId(candidateId);
    }
    
    public int getVotesForElection(Integer electionId) {
        return voteRepo.countByElectionId(electionId);
    }
}
