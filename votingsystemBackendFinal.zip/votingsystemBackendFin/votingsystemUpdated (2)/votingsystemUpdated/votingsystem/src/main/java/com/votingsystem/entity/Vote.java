package com.votingsystem.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "votes")
public class Vote {

    @Id
    @GeneratedValue(generator="vote_seq")
    @SequenceGenerator(
            name = "vote_seq",
            sequenceName = "vote_SEQ",
            allocationSize = 1,
            initialValue = 2000   // You can change starting ID
    )
    @Column(name = "vote_id")
    private int id;

    @ManyToOne
    @JoinColumn(name = "voter_id", nullable = false)  // Foreign Key
    @JsonIgnore
    private Voter voter;

    @ManyToOne
    @JoinColumn(name = "candidate_id", nullable = false) // Foreign Key
    @JsonIgnore
    private Candidate candidate;

    @ManyToOne
    @JoinColumn(name = "election_id", nullable = false) // Foreign Key
    @JsonIgnore
    private Election election;

    // ------------------ GETTERS & SETTERS ------------------

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Voter getVoter() {
        return voter;
    }

    public void setVoter(Voter voter) {
        this.voter = voter;
    }

    public Candidate getCandidate() {
        return candidate;
    }

    public void setCandidate(Candidate candidate) {
        this.candidate = candidate;
    }

    public Election getElection() {
        return election;
    }

    public void setElection(Election election) {
        this.election = election;
    }
}
