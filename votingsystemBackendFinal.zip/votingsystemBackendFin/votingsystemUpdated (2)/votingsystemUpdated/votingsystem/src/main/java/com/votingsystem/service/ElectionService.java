package com.votingsystem.service;

import org.springframework.stereotype.Service;
import java.util.List;

import com.votingsystem.entity.Election;
import com.votingsystem.repository.ElectionRepository;
import com.votingsystem.exception.ResourceNotFoundException;

@Service
public class ElectionService {

    private final ElectionRepository electionRepo;

    public ElectionService(ElectionRepository electionRepo) {
        this.electionRepo = electionRepo;
    }

    // -------- CREATE ----------
    public Election createElection(Election e) {
        return electionRepo.save(e);
    }

    // -------- GET ALL ----------
    public List<Election> getAll() {
        return electionRepo.findAll();
    }

    // -------- GET ONE ----------
    public Election getById(Integer id) {
        return electionRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Election not found"));
    }

    // -------- UPDATE ----------
    public Election update(Integer id, Election updated) {
        Election e = getById(id);

        e.setTitle(updated.getTitle());
        e.setStartAt(updated.getStartAt());
        e.setEndAt(updated.getEndAt());
        e.setActive(updated.isActive());

        return electionRepo.save(e);
    }

    // -------- DELETE ----------
    public void delete(Integer id) {
        Election e = getById(id);
        electionRepo.delete(e);
    }
    public List<Election> getActiveElections() {
        return electionRepo.findByActiveTrue();
    }

}
