package com.votingsystem.entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "elections")
public class Election {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  // ✅ FIXED
    @Column(name = "election_id")
    private int id;

    @Column(length = 50, name = "election_title", nullable = false)
    private String title;

    @Column(name = "start_time")
    private LocalDateTime startAt;

    @Column(name = "end_time")
    private LocalDateTime endAt;

    @Column(name = "is_active")
    private boolean active;

    @OneToMany(mappedBy = "election")
    @JsonManagedReference
    private List<Candidate> candidates;

    @OneToMany(mappedBy = "election")
    @JsonIgnore
    private List<Vote> votes;
    
    // getters & setters

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public LocalDateTime getStartAt() {
		return startAt;
	}

	public void setStartAt(LocalDateTime startAt) {
		this.startAt = startAt;
	}

	public LocalDateTime getEndAt() {
		return endAt;
	}

	public void setEndAt(LocalDateTime endAt) {
		this.endAt = endAt;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public List<Candidate> getCandidates() {
		return candidates;
	}

	public void setCandidates(List<Candidate> candidates) {
		this.candidates = candidates;
	}

	public List<Vote> getVotes() {
		return votes;
	}

	public void setVotes(List<Vote> votes) {
		this.votes = votes;
	}

	@Override
	public String toString() {
		return "Election [id=" + id + ", title=" + title + ", startAt=" + startAt + ", endAt=" + endAt + ", active="
				+ active + ", candidates=" + candidates + ", votes=" + votes + "]";
	}

   
    
}
