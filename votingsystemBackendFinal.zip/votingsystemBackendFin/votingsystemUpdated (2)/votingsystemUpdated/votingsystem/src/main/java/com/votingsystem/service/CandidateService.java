package com.votingsystem.service;

import org.springframework.stereotype.Service;
import java.util.List;

import com.votingsystem.entity.Candidate;
import com.votingsystem.entity.Election;
import com.votingsystem.repository.CandidateRepository;
import com.votingsystem.repository.ElectionRepository;
import com.votingsystem.exception.ResourceNotFoundException;

@Service
public class CandidateService {

    private final CandidateRepository candidateRepo;
    private final ElectionRepository electionRepo;

    public CandidateService(CandidateRepository candidateRepo, ElectionRepository electionRepo) {
        this.candidateRepo = candidateRepo;
        this.electionRepo = electionRepo;
    }

    // -------- ADD CANDIDATE ----------
    public Candidate addCandidate(Integer electionId, Candidate c) {
        Election e = electionRepo.findById(electionId)
                .orElseThrow(() -> new ResourceNotFoundException("Election not found"));
        c.setElection(e);
        return candidateRepo.save(c);
    }

    // -------- GET ALL ----------
    public List<Candidate> getAll() {
        return candidateRepo.findAll();
    }

    // -------- GET BY ID ----------
    public Candidate getById(Integer id) {
        return candidateRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Candidate not found"));
    }

    // -------- UPDATE ----------
    public Candidate update(Integer id, Candidate newData) {
        Candidate c = getById(id);
        c.setName(newData.getName());
        c.setParty(newData.getParty());
        return candidateRepo.save(c);
    }

    // -------- DELETE ----------
    public void delete(Integer id) {
        Candidate c = getById(id);
        candidateRepo.delete(c);
    }
    public List<Candidate> getByElection(Integer electionId) {
        return candidateRepo.findByElection_Id(electionId);
    }

}
