package com.votingsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import com.votingsystem.entity.Voter;

public interface VoterRepository extends JpaRepository<Voter, Integer> {

    Optional<Voter> findByEmail(String email);

    boolean existsByEmail(String email);
}
