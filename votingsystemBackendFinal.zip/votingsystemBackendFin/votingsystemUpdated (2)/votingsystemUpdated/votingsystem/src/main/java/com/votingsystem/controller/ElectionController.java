package com.votingsystem.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.votingsystem.entity.Election;
import com.votingsystem.service.ElectionService;

@RestController
@RequestMapping("/api/elections")
@CrossOrigin
public class ElectionController {

    private final ElectionService electionService;

    public ElectionController(ElectionService electionService) {
        this.electionService = electionService;
    }

    // CREATE
    @PostMapping("/create")
    public Election create(@RequestBody Election election) {
        return electionService.createElection(election);
    }

    // GET ALL
    @GetMapping("/all")
    public List<Election> getAll() {
        return electionService.getAll();
    }

    // GET ONE
    @GetMapping("/{id}")
    public Election getById(@PathVariable Integer id) {
        return electionService.getById(id);
    }

    // UPDATE
    @PutMapping("/{id}")
    public Election update(@PathVariable Integer id, @RequestBody Election updated) {
        return electionService.update(id, updated);
    }

    // DELETE
    @DeleteMapping("/{id}")
    public String delete(@PathVariable Integer id) {
        electionService.delete(id);
        return "Election deleted successfully!";
    }
    @GetMapping("/all-active")
    public List<Election> getActive() {
        return electionService.getActiveElections();
    }

}
